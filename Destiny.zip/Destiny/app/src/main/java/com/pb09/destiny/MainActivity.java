package com.pb09.destiny;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // TODO: Steps 4 & 8 - Declare member variables here:
    private int mIndex=1;
    private int mStoryNo;

    TextView QuestionTxtView;
    Button TopButton,BottomButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // TODO: Step 5 - Wire up the 3 views from the layout to the member variables:
        QuestionTxtView=findViewById(R.id.storyTextView);
        TopButton=findViewById(R.id.buttonTop);
        BottomButton=findViewById(R.id.buttonBottom);


        // TODO: Steps 6, 7, & 9 - Set a listener on the top button:
        TopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Destiny!", "Top Button Clicked");
                if(mIndex==1||mIndex==2) {
                    QuestionTxtView.setText(R.string.T3_Story);
                    TopButton.setText(R.string.T3_Ans1);
                    BottomButton.setText(R.string.T3_Ans2);
                    mIndex=3;
                }else {
                    QuestionTxtView.setText(R.string.T6_End);
                    TopButton.setVisibility(View.GONE);
                    BottomButton.setVisibility(View.GONE);
                }
            }
        });

        // TODO: Steps 6, 7, & 9 - Set a listener on the bottom button:
        BottomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Destiny!", "Bottom Button Clicked!");
                if(mIndex == 1 ){
                    QuestionTxtView.setText(R.string.T2_Story);
                    TopButton.setText(R.string.T2_Ans1);
                    BottomButton.setText(R.string.T2_Ans2);
                    mIndex=2;
                }else if(mIndex == 2){
                    QuestionTxtView.setText(R.string.T4_End);
                    TopButton.setVisibility(View.GONE);
                    BottomButton.setVisibility(View.GONE);
                }else{
                    QuestionTxtView.setText(R.string.T5_End);
                    TopButton.setVisibility(View.GONE);
                    BottomButton.setVisibility(View.GONE);
                }
            }
        });
    }

}